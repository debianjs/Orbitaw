#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <algorithm>
#include <memory>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <regex>
#include <cmath>
#include <iomanip>
#include <functional>
#include <queue>
#include <random>
#include <cstring>
#include <cstdlib>
#include <csignal>

#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>

#include <openssl/sha.h>
#include <openssl/md5.h>
#include <curl/curl.h>
#include <json/json.h>
#include <maxminddb.h>
#include <sqlite3.h>
#include <hiredis/hiredis.h>

namespace VPNDetector {

constexpr int VERSION_MAJOR = 2;
constexpr int VERSION_MINOR = 0;
constexpr int VERSION_PATCH = 0;

constexpr int DEFAULT_CACHE_TTL = 3600;
constexpr int MAX_RETRY_ATTEMPTS = 3;
constexpr double SUSPICIOUS_LATENCY_THRESHOLD = 150.0;
constexpr int RATE_LIMIT_WINDOW = 60;
constexpr int MAX_REQUESTS_PER_WINDOW = 100;

enum class IPType {
    RESIDENTIAL,
    DATACENTER,
    VPN,
    PROXY,
    TOR,
    HOSTING,
    EDUCATION,
    GOVERNMENT,
    UNKNOWN
};

enum class RiskLevel {
    SAFE = 0,
    LOW = 25,
    MEDIUM = 50,
    HIGH = 75,
    CRITICAL = 100
};

struct GeoLocation {
    double latitude;
    double longitude;
    std::string country;
    std::string city;
    std::string timezone;
    std::string isp;
    std::string organization;
    int asn;

    double calculateDistance(const GeoLocation& other) const {
        constexpr double R = 6371.0;
        double lat1 = latitude * M_PI / 180.0;
        double lat2 = other.latitude * M_PI / 180.0;
        double dlat = (other.latitude - latitude) * M_PI / 180.0;
        double dlon = (other.longitude - longitude) * M_PI / 180.0;

        double a = sin(dlat/2) * sin(dlat/2) +
                  cos(lat1) * cos(lat2) * sin(dlon/2) * sin(dlon/2);
        double c = 2 * atan2(sqrt(a), sqrt(1-a));
        return R * c;
    }
};

struct IPAnalysis {
    std::string ip;
    IPType type;
    RiskLevel risk;
    GeoLocation location;
    std::vector<std::string> flags;
    std::map<std::string, double> scores;
    std::chrono::system_clock::time_point timestamp;
    double confidence;

    int getTotalScore() const {
        double total = 0;
        for (const auto& [key, value] : scores) {
            total += value;
        }
        return static_cast<int>(total);
    }
};

struct SessionFingerprint {
    std::string userAgent;
    std::string acceptLanguage;
    std::string acceptEncoding;
    std::vector<std::string> fonts;
    std::string timezone;
    std::string screenResolution;
    std::string colorDepth;
    std::string platform;
    bool cookiesEnabled;
    bool doNotTrack;
    std::string webglVendor;
    std::string canvasFingerprint;

    std::string generateHash() const {
        std::stringstream ss;
        ss << userAgent << acceptLanguage << acceptEncoding 
           << timezone << screenResolution << platform;

        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256_CTX sha256;
        SHA256_Init(&sha256);
        std::string data = ss.str();
        SHA256_Update(&sha256, data.c_str(), data.length());
        SHA256_Final(hash, &sha256);

        std::stringstream result;
        for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
            result << std::hex << std::setw(2) << std::setfill('0') 
                  << static_cast<int>(hash[i]);
        }
        return result.str();
    }
};

class DatabaseManager {
private:
    sqlite3* db;
    redisContext* redis;
    std::mutex dbMutex;

public:
    DatabaseManager() : db(nullptr), redis(nullptr) {
        initializeSQLite();
        initializeRedis();
    }

    ~DatabaseManager() {
        if (db) sqlite3_close(db);
        if (redis) redisFree(redis);
    }

    void initializeSQLite() {
        int rc = sqlite3_open("vpn_detector.db", &db);
        if (rc != SQLITE_OK) {
            throw std::runtime_error("Cannot open database: " + 
                                   std::string(sqlite3_errmsg(db)));
        }

        const char* createTables = R"(
            CREATE TABLE IF NOT EXISTS ip_reputation (
                ip TEXT PRIMARY KEY,
                type TEXT,
                risk_level INTEGER,
                last_seen TIMESTAMP,
                reports INTEGER DEFAULT 0,
                provider TEXT,
                asn INTEGER,
                country TEXT
            );

            CREATE TABLE IF NOT EXISTS session_history (
                session_id TEXT,
                ip TEXT,
                fingerprint TEXT,
                timestamp TIMESTAMP,
                location TEXT,
                suspicious_flags TEXT
            );

            CREATE TABLE IF NOT EXISTS blocked_ranges (
                cidr TEXT PRIMARY KEY,
                provider TEXT,
                reason TEXT,
                added_date TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_session_fingerprint 
            ON session_history(fingerprint);
        )";

        char* errMsg = nullptr;
        rc = sqlite3_exec(db, createTables, nullptr, nullptr, &errMsg);
        if (rc != SQLITE_OK) {
            std::string error = errMsg;
            sqlite3_free(errMsg);
            throw std::runtime_error("SQL error: " + error);
        }
    }

    void initializeRedis() {
        redis = redisConnect("127.0.0.1", 6379);
        if (redis == nullptr || redis->err) {
            if (redis) {
                std::cerr << "Redis connection error: " << redis->errstr << std::endl;
                redisFree(redis);
                redis = nullptr;
            }
        }
    }

    bool isIPCached(const std::string& ip) {
        if (!redis) return false;

        redisReply* reply = (redisReply*)redisCommand(redis, "GET ip:%s", ip.c_str());
        if (reply == nullptr) return false;

        bool exists = (reply->type == REDIS_REPLY_STRING);
        freeReplyObject(reply);
        return exists;
    }

    void cacheIPAnalysis(const IPAnalysis& analysis) {
        if (!redis) return;

        Json::Value root;
        root["ip"] = analysis.ip;
        root["type"] = static_cast<int>(analysis.type);
        root["risk"] = static_cast<int>(analysis.risk);
        root["confidence"] = analysis.confidence;

        Json::StreamWriterBuilder builder;
        std::string jsonStr = Json::writeString(builder, root);

        redisCommand(redis, "SETEX ip:%s %d %s", 
                    analysis.ip.c_str(), DEFAULT_CACHE_TTL, jsonStr.c_str());
    }

    void recordSession(const std::string& sessionId, const IPAnalysis& analysis,
                       const SessionFingerprint& fingerprint) {
        std::lock_guard<std::mutex> lock(dbMutex);

        const char* sql = R"(
            INSERT INTO session_history 
            (session_id, ip, fingerprint, timestamp, location, suspicious_flags)
            VALUES (?, ?, ?, datetime('now'), ?, ?)
        )";

        sqlite3_stmt* stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);

        sqlite3_bind_text(stmt, 1, sessionId.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, analysis.ip.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 3, fingerprint.generateHash().c_str(), -1, SQLITE_STATIC);

        std::string location = analysis.location.country + ", " + analysis.location.city;
        sqlite3_bind_text(stmt, 4, location.c_str(), -1, SQLITE_STATIC);

        std::stringstream flags;
        for (const auto& flag : analysis.flags) {
            flags << flag << ";";
        }
        sqlite3_bind_text(stmt, 5, flags.str().c_str(), -1, SQLITE_STATIC);

        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }
};

class NetworkAnalyzer {
private:
    MMDB_s mmdb;
    std::unordered_map<int, std::string> asnDatabase;
    std::unordered_set<std::string> vpnPorts;
    std::mutex analyzerMutex;

public:
    NetworkAnalyzer() {
        loadGeoIPDatabase();
        loadASNDatabase();
        initializeVPNPorts();
    }

    ~NetworkAnalyzer() {
        MMDB_close(&mmdb);
    }

    void loadGeoIPDatabase() {
        int status = MMDB_open("./GeoLite2-City.mmdb", 
                              MMDB_MODE_MMAP, &mmdb);
        if (status != MMDB_SUCCESS) {
            throw std::runtime_error("Cannot open GeoIP database: " + 
                                   std::string(MMDB_strerror(status)));
        }
    }

    void loadASNDatabase() {
        std::ifstream file("asn_database.csv");
        std::string line;
        while (std::getline(file, line)) {
            std::istringstream iss(line);
            int asn;
            std::string org;
            if (iss >> asn) {
                std::getline(iss, org);
                asnDatabase[asn] = org;
            }
        }
    }

    void initializeVPNPorts() {
        vpnPorts = {"1194", "1701", "500", "4500", "51820", "1723", "47", "50", "51"};
    }

    GeoLocation getGeoLocation(const std::string& ip) {
        GeoLocation loc;
        int gai_error, mmdb_error;

        MMDB_lookup_result_s result = MMDB_lookup_string(&mmdb, ip.c_str(), 
                                                         &gai_error, &mmdb_error);

        if (gai_error != 0 || mmdb_error != MMDB_SUCCESS) {
            loc.country = "Unknown";
            loc.city = "Unknown";
            return loc;
        }

        if (result.found_entry) {
            MMDB_entry_data_s entry_data;

            MMDB_get_value(&result.entry, &entry_data, "location", "latitude", NULL);
            if (entry_data.has_data) loc.latitude = entry_data.double_value;

            MMDB_get_value(&result.entry, &entry_data, "location", "longitude", NULL);
            if (entry_data.has_data) loc.longitude = entry_data.double_value;

            MMDB_get_value(&result.entry, &entry_data, "country", "names", "en", NULL);
            if (entry_data.has_data) {
                loc.country = std::string(entry_data.utf8_string, entry_data.data_size);
            }

            MMDB_get_value(&result.entry, &entry_data, "city", "names", "en", NULL);
            if (entry_data.has_data) {
                loc.city = std::string(entry_data.utf8_string, entry_data.data_size);
            }

            MMDB_get_value(&result.entry, &entry_data, "traits", "isp", NULL);
            if (entry_data.has_data) {
                loc.isp = std::string(entry_data.utf8_string, entry_data.data_size);
            }

            MMDB_get_value(&result.entry, &entry_data, "traits", "autonomous_system_number", NULL);
            if (entry_data.has_data) {
                loc.asn = entry_data.uint32;
            }
        }

        return loc;
    }

    double measureLatency(const std::string& ip) {
        auto start = std::chrono::high_resolution_clock::now();

        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) return -1;

        fcntl(sockfd, F_SETFL, O_NONBLOCK);

        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(80);
        inet_pton(AF_INET, ip.c_str(), &addr.sin_addr);

        connect(sockfd, (struct sockaddr*)&addr, sizeof(addr));

        fd_set fdset;
        FD_ZERO(&fdset);
        FD_SET(sockfd, &fdset);

        struct timeval tv;
        tv.tv_sec = 2;
        tv.tv_usec = 0;

        if (select(sockfd + 1, nullptr, &fdset, nullptr, &tv) > 0) {
            int error;
            socklen_t len = sizeof(error);
            getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len);

            close(sockfd);

            if (error == 0) {
                auto end = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double, std::milli> latency = end - start;
                return latency.count();
            }
        }

        close(sockfd);
        return -1;
    }

    IPType classifyASN(int asn) {
        if (asnDatabase.find(asn) == asnDatabase.end()) {
            return IPType::UNKNOWN;
        }

        std::string org = asnDatabase[asn];
        std::transform(org.begin(), org.end(), org.begin(), ::tolower);

        if (org.find("amazon") != std::string::npos ||
            org.find("google") != std::string::npos ||
            org.find("microsoft") != std::string::npos ||
            org.find("digitalocean") != std::string::npos ||
            org.find("linode") != std::string::npos ||
            org.find("vultr") != std::string::npos) {
            return IPType::DATACENTER;
        }

        if (org.find("vpn") != std::string::npos ||
            org.find("virtual private") != std::string::npos ||
            org.find("nordvpn") != std::string::npos ||
            org.find("expressvpn") != std::string::npos ||
            org.find("surfshark") != std::string::npos) {
            return IPType::VPN;
        }

        if (org.find("proxy") != std::string::npos ||
            org.find("anonymizer") != std::string::npos) {
            return IPType::PROXY;
        }

        if (org.find("tor") != std::string::npos) {
            return IPType::TOR;
        }

        if (org.find("comcast") != std::string::npos ||
            org.find("verizon") != std::string::npos ||
            org.find("at&t") != std::string::npos ||
            org.find("spectrum") != std::string::npos ||
            org.find("residential") != std::string::npos) {
            return IPType::RESIDENTIAL;
        }

        if (org.find("university") != std::string::npos ||
            org.find("college") != std::string::npos ||
            org.find("edu") != std::string::npos) {
            return IPType::EDUCATION;
        }

        return IPType::UNKNOWN;
    }

    std::vector<std::string> checkDNSReverse(const std::string& ip) {
        std::vector<std::string> results;
        struct sockaddr_in sa;
        char host[NI_MAXHOST];

        sa.sin_family = AF_INET;
        inet_pton(AF_INET, ip.c_str(), &sa.sin_addr);

        if (getnameinfo((struct sockaddr*)&sa, sizeof(sa), 
                       host, sizeof(host), nullptr, 0, 0) == 0) {
            results.push_back(host);

            std::string hostname(host);
            std::transform(hostname.begin(), hostname.end(), hostname.begin(), ::tolower);

            if (hostname.find("vpn") != std::string::npos ||
                hostname.find("proxy") != std::string::npos ||
                hostname.find("tor") != std::string::npos ||
                hostname.find("anonymous") != std::string::npos) {
                results.push_back("SUSPICIOUS_HOSTNAME");
            }
        }

        return results;
    }
};

class ReputationChecker {
private:
    std::vector<std::string> blacklistServers;
    std::unordered_map<std::string, std::chrono::system_clock::time_point> cache;
    std::mutex cacheMutex;

    static size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
        ((std::string*)userp)->append((char*)contents, size * nmemb);
        return size * nmemb;
    }

public:
    ReputationChecker() {
        blacklistServers = {
            "zen.spamhaus.org",
            "bl.spamcop.net",
            "dnsbl.sorbs.net",
            "cbl.abuseat.org",
            "b.barracudacentral.org"
        };
    }

    bool checkBlacklist(const std::string& ip) {
        for (const auto& server : blacklistServers) {
            if (queryDNSBL(ip, server)) {
                return true;
            }
        }
        return false;
    }

    bool queryDNSBL(const std::string& ip, const std::string& server) {
        std::vector<std::string> octets;
        std::stringstream ss(ip);
        std::string octet;

        while (std::getline(ss, octet, '.')) {
            octets.push_back(octet);
        }

        std::reverse(octets.begin(), octets.end());

        std::string query;
        for (const auto& o : octets) {
            query += o + ".";
        }
        query += server;

        struct hostent* host = gethostbyname(query.c_str());
        return (host != nullptr);
    }

    Json::Value checkIPQuality(const std::string& ip) {
        CURL* curl = curl_easy_init();
        Json::Value result;

        if (!curl) return result;

        std::string response;
        std::string url = "https://ipqualityscore.com/api/json/ip/YOUR_API_KEY/" + ip;

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);

        CURLcode res = curl_easy_perform(curl);

        if (res == CURLE_OK) {
            Json::CharReaderBuilder builder;
            std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
            std::string errors;

            reader->parse(response.c_str(), response.c_str() + response.size(), 
                         &result, &errors);
        }

        curl_easy_cleanup(curl);
        return result;
    }

    std::vector<std::string> checkThreatIntel(const std::string& ip) {
        std::vector<std::string> threats;

        Json::Value ipquality = checkIPQuality(ip);
        if (!ipquality.empty()) {
            if (ipquality["proxy"].asBool()) threats.push_back("PROXY_DETECTED");
            if (ipquality["vpn"].asBool()) threats.push_back("VPN_DETECTED");
            if (ipquality["tor"].asBool()) threats.push_back("TOR_DETECTED");
            if (ipquality["hosting"].asBool()) threats.push_back("HOSTING_DETECTED");
            if (ipquality["bot_status"].asBool()) threats.push_back("BOT_DETECTED");
        }

        if (checkBlacklist(ip)) {
            threats.push_back("BLACKLISTED");
        }

        return threats;
    }
};

class HTTPHeaderAnalyzer {
private:
    std::vector<std::string> suspiciousHeaders;
    std::map<std::string, int> headerScores;

public:
    HTTPHeaderAnalyzer() {
        suspiciousHeaders = {
            "X-Forwarded-For",
            "X-Real-IP",
            "X-Originating-IP",
            "X-Remote-IP",
            "X-Remote-Addr",
            "Via",
            "Forwarded",
            "Proxy-Connection",
            "X-ProxyUser-Ip",
            "Client-IP",
            "X-Forwarded-Host",
            "X-Forwarded-Server",
            "X-Forwarded-Proto"
        };

        headerScores = {
            {"X-Forwarded-For", 20},
            {"Via", 25},
            {"Proxy-Connection", 30},
            {"X-Real-IP", 15},
            {"Forwarded", 20}
        };
    }

    int analyzeHeaders(const std::map<std::string, std::string>& headers) {
        int totalScore = 0;

        for (const auto& [header, value] : headers) {
            if (headerScores.find(header) != headerScores.end()) {
                totalScore += headerScores[header];
            }

            if (header == "X-Forwarded-For" && value.find(",") != std::string::npos) {
                totalScore += 10;
            }

            if (header == "User-Agent") {
                if (value.find("bot") != std::string::npos ||
                    value.find("crawler") != std::string::npos ||
                    value.find("spider") != std::string::npos) {
                    totalScore += 15;
                }
            }
        }

        return totalScore;
    }

    bool detectHeaderInconsistencies(const std::map<std::string, std::string>& headers) {
        std::vector<std::string> reportedIPs;

        for (const auto& [header, value] : headers) {
            if (header == "X-Forwarded-For" || header == "X-Real-IP" ||
                header == "Client-IP" || header == "X-Originating-IP") {
                reportedIPs.push_back(value);
            }
        }

        if (reportedIPs.size() > 1) {
            std::sort(reportedIPs.begin(), reportedIPs.end());
            reportedIPs.erase(std::unique(reportedIPs.begin(), reportedIPs.end()), 
                             reportedIPs.end());
            return reportedIPs.size() > 1;
        }

        return false;
    }
};

class PortScanDetector {
private:
    std::unordered_map<std::string, std::vector<std::pair<int, std::chrono::system_clock::time_point>>> portHistory;
    std::mutex portMutex;
    
public:
    struct ScanInfo {
        int uniquePorts;
        double scanRate;
        std::chrono::seconds timeWindow;
        std::vector<int> commonPorts;
    };
    
    void logPortAccess(const std::string& ip, int port) {
        std::lock_guard<std::mutex> lock(portMutex);
        auto now = std::chrono::system_clock::now();
        
        if (portHistory.find(ip) == portHistory.end()) {
            portHistory[ip] = std::vector<std::pair<int, std::chrono::system_clock::time_point>>();
        }
        
        portHistory[ip].push_back({port, now});
        
        auto& history = portHistory[ip];
        history.erase(
            std::remove_if(history.begin(), history.end(),
                [now](const auto& entry) {
                    return std::chrono::duration_cast<std::chrono::minutes>(now - entry.second).count() > 10;
                }),
            history.end()
        );
    }
    
    ScanInfo analyzePortPattern(const std::string& ip) {
        std::lock_guard<std::mutex> lock(portMutex);
        ScanInfo info = {0, 0.0, std::chrono::seconds(0), {}};
        
        if (portHistory.find(ip) == portHistory.end()) {
            return info;
        }
        
        auto& history = portHistory[ip];
        std::unordered_set<int> uniquePorts;
        
        for (const auto& entry : history) {
            uniquePorts.insert(entry.first);
            info.commonPorts.push_back(entry.first);
        }
        
        info.uniquePorts = uniquePorts.size();
        
        if (history.size() > 1) {
            auto timeSpan = std::chrono::duration_cast<std::chrono::seconds>(
                history.back().second - history.front().second
            );
            info.timeWindow = timeSpan;
            
            if (timeSpan.count() > 0) {
                info.scanRate = static_cast<double>(history.size()) / timeSpan.count();
            }
        }
        
        return info;
    }
    
    bool isPortScanPattern(const std::string& ip) {
        ScanInfo info = analyzePortPattern(ip);
        
        if (info.uniquePorts > 20) return true;
        if (info.scanRate > 5.0) return true;
        if (info.uniquePorts > 10 && info.scanRate > 2.0) return true;
        
        std::vector<int> suspiciousPorts = {22, 23, 80, 443, 135, 139, 445, 993, 995, 1433, 3389, 5432};
        int suspiciousCount = 0;
        for (int port : info.commonPorts) {
            if (std::find(suspiciousPorts.begin(), suspiciousPorts.end(), port) != suspiciousPorts.end()) {
                suspiciousCount++;
            }
        }
        
        if (suspiciousCount > 5) return true;
        
        return false;
    }
    
    double calculateScanScore(const std::string& ip) {
        ScanInfo info = analyzePortPattern(ip);
        double score = 0.0;
        
        score += std::min(info.uniquePorts * 2.0, 50.0);
        score += std::min(info.scanRate * 10.0, 30.0);
        
        if (info.timeWindow.count() < 60 && info.uniquePorts > 5) {
            score += 20.0;
        }
        
        return std::min(score, 100.0);
    }
};

class TimingAnalyzer {
private:
    std::unordered_map<std::string, std::vector<double>> latencyHistory;
    std::mutex timingMutex;
    
public:
    struct TimingProfile {
        double averageLatency;
        double jitter;
        double minLatency;
        double maxLatency;
        double variance;
        std::vector<double> samples;
    };
    
    void recordLatency(const std::string& ip, double latency) {
        std::lock_guard<std::mutex> lock(timingMutex);
        
        if (latencyHistory.find(ip) == latencyHistory.end()) {
            latencyHistory[ip] = std::vector<double>();
        }
        
        latencyHistory[ip].push_back(latency);
        
        if (latencyHistory[ip].size() > 50) {
            latencyHistory[ip].erase(latencyHistory[ip].begin());
        }
    }
    
    TimingProfile analyzeTimingPattern(const std::string& ip) {
        std::lock_guard<std::mutex> lock(timingMutex);
        TimingProfile profile = {0.0, 0.0, 0.0, 0.0, 0.0, {}};
        
        if (latencyHistory.find(ip) == latencyHistory.end() || latencyHistory[ip].empty()) {
            return profile;
        }
        
        auto& latencies = latencyHistory[ip];
        profile.samples = latencies;
        
        double sum = 0.0;
        profile.minLatency = *std::min_element(latencies.begin(), latencies.end());
        profile.maxLatency = *std::max_element(latencies.begin(), latencies.end());
        
        for (double lat : latencies) {
            sum += lat;
        }
        profile.averageLatency = sum / latencies.size();
        
        double varianceSum = 0.0;
        for (double lat : latencies) {
            varianceSum += std::pow(lat - profile.averageLatency, 2);
        }
        profile.variance = varianceSum / latencies.size();
        
        profile.jitter = profile.maxLatency - profile.minLatency;
        
        return profile;
    }
    
    bool detectVPNLatencyPattern(const std::string& ip) {
        TimingProfile profile = analyzeTimingPattern(ip);
        
        if (profile.samples.size() < 3) return false;
        
        if (profile.averageLatency > 200.0) return true;
        
        if (profile.jitter > 100.0 && profile.averageLatency > 50.0) return true;
        
        if (profile.variance > 500.0) return true;
        
        double consistencyThreshold = 5.0;
        bool tooConsistent = profile.jitter < consistencyThreshold && profile.samples.size() > 10;
        if (tooConsistent) return true;
        
        return false;
    }
    
    double calculateTimingScore(const std::string& ip) {
        TimingProfile profile = analyzeTimingPattern(ip);
        double score = 0.0;
        
        if (profile.averageLatency > 150.0) {
            score += std::min((profile.averageLatency - 150.0) / 10.0, 30.0);
        }
        
        if (profile.jitter > 50.0) {
            score += std::min(profile.jitter / 5.0, 25.0);
        }
        
        if (profile.variance > 200.0) {
            score += std::min(profile.variance / 20.0, 20.0);
        }
        
        if (profile.jitter < 2.0 && profile.samples.size() > 10) {
            score += 25.0;
        }
        
        return std::min(score, 100.0);
    }
    
    double measureLatency(const std::string& ip) {
        auto start = std::chrono::high_resolution_clock::now();
        
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock == -1) return -1.0;
        
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(80);
        
        if (inet_pton(AF_INET, ip.c_str(), &addr.sin_addr) <= 0) {
            close(sock);
            return -1.0;
        }
        
        fcntl(sock, F_SETFL, O_NONBLOCK);
        
        int result = connect(sock, (struct sockaddr*)&addr, sizeof(addr));
        
        if (result == -1 && errno != EINPROGRESS) {
            close(sock);
            return -1.0;
        }
        
        fd_set write_fds;
        FD_ZERO(&write_fds);
        FD_SET(sock, &write_fds);
        
        struct timeval timeout;
        timeout.tv_sec = 3;
        timeout.tv_usec = 0;
        
        result = select(sock + 1, nullptr, &write_fds, nullptr, &timeout);
        
        close(sock);
        
        auto end = std::chrono::high_resolution_clock::now();
        double latency = std::chrono::duration<double, std::milli>(end - start).count();
        
        if (result <= 0) {
            return -1.0;
        }
        
        recordLatency(ip, latency);
        return latency;
    }
};

class MachineLearningDetector {
public:
    struct Feature {
        double latency;
        int asnType;
        int headerScore;
        bool blacklisted;
        int geoInconsistency;
        double timeOfDay;
        int requestRate;
    };

private:
    std::vector<double> weights;
    double bias;

public:
    MachineLearningDetector() {
        weights = {0.3, 0.25, 0.2, 0.35, 0.25, 0.1, 0.15};
        bias = -0.5;
    }

    double predict(const Feature& features) {
        std::vector<double> normalized = normalizeFeatures(features);

        double score = bias;
        for (size_t i = 0; i < weights.size() && i < normalized.size(); ++i) {
            score += weights[i] * normalized[i];
        }

        return sigmoid(score);
    }

    std::vector<double> normalizeFeatures(const Feature& features) {
        return {
            features.latency / 1000.0,
            static_cast<double>(features.asnType) / 10.0,
            features.headerScore / 100.0,
            features.blacklisted ? 1.0 : 0.0,
            features.geoInconsistency / 10000.0,
            features.timeOfDay / 24.0,
            features.requestRate / 100.0
        };
    }

    double sigmoid(double x) {
        return 1.0 / (1.0 + exp(-x));
    }

    void updateModel(const Feature& features, bool isVPN) {
        double prediction = predict(features);
        double error = (isVPN ? 1.0 : 0.0) - prediction;
        double learningRate = 0.01;

        std::vector<double> normalized = normalizeFeatures(features);

        for (size_t i = 0; i < weights.size() && i < normalized.size(); ++i) {
            weights[i] += learningRate * error * normalized[i];
        }
        bias += learningRate * error;
    }
};

class RateLimiter {
private:
    struct ClientInfo {
        std::queue<std::chrono::system_clock::time_point> requests;
        bool blocked;
    };

    std::unordered_map<std::string, ClientInfo> clients;
    std::mutex rateMutex;

public:
    bool checkRateLimit(const std::string& ip) {
        std::lock_guard<std::mutex> lock(rateMutex);

        auto now = std::chrono::system_clock::now();
        auto& client = clients[ip];

        if (client.blocked) {
            return false;
        }

        while (!client.requests.empty()) {
            auto diff = std::chrono::duration_cast<std::chrono::seconds>
                       (now - client.requests.front()).count();
            if (diff > RATE_LIMIT_WINDOW) {
                client.requests.pop();
            } else {
                break;
            }
        }

        if (client.requests.size() >= MAX_REQUESTS_PER_WINDOW) {
            client.blocked = true;
            return false;
        }

        client.requests.push(now);
        return true;
    }

    void unblockIP(const std::string& ip) {
        std::lock_guard<std::mutex> lock(rateMutex);
        if (clients.find(ip) != clients.end()) {
            clients[ip].blocked = false;
        }
    }
};

class VPNDetectorEngine {
private:
    std::unique_ptr<DatabaseManager> dbManager;
    std::unique_ptr<NetworkAnalyzer> netAnalyzer;
    std::unique_ptr<ReputationChecker> repChecker;
    std::unique_ptr<HTTPHeaderAnalyzer> headerAnalyzer;
    std::unique_ptr<MachineLearningDetector> mlDetector;
    std::unique_ptr<RateLimiter> rateLimiter;
    std::unique_ptr<PortScanDetector> portScanner;
    std::unique_ptr<TimingAnalyzer> timingAnalyzer;

    std::atomic<bool> running;
    std::thread cleanupThread;

public:
    VPNDetectorEngine() : running(true) {
        dbManager = std::make_unique<DatabaseManager>();
        netAnalyzer = std::make_unique<NetworkAnalyzer>();
        repChecker = std::make_unique<ReputationChecker>();
        headerAnalyzer = std::make_unique<HTTPHeaderAnalyzer>();
        mlDetector = std::make_unique<MachineLearningDetector>();
        rateLimiter = std::make_unique<RateLimiter>();
        portScanner = std::make_unique<PortScanDetector>();
        timingAnalyzer = std::make_unique<TimingAnalyzer>();

        cleanupThread = std::thread(&VPNDetectorEngine::cleanupWorker, this);
    }

    ~VPNDetectorEngine() {
        running = false;
        if (cleanupThread.joinable()) {
            cleanupThread.join();
        }
    }

    void cleanupWorker() {
        while (running) {
            std::this_thread::sleep_for(std::chrono::minutes(5));
        }
    }

    IPAnalysis analyzeIP(const std::string& ip, 
                         const std::map<std::string, std::string>& headers,
                         const SessionFingerprint& fingerprint) {

        IPAnalysis analysis;
        analysis.ip = ip;
        analysis.timestamp = std::chrono::system_clock::now();

        if (!rateLimiter->checkRateLimit(ip)) {
            analysis.risk = RiskLevel::CRITICAL;
            analysis.flags.push_back("RATE_LIMIT_EXCEEDED");
            return analysis;
        }

        GeoLocation location = netAnalyzer->getGeoLocation(ip);
        analysis.location = location;

        IPType ipType = netAnalyzer->classifyASN(location.asn);
        analysis.type = ipType;

        int headerScore = headerAnalyzer->analyzeHeaders(headers);
        analysis.scores["header_analysis"] = headerScore;

        if (headerAnalyzer->detectHeaderInconsistencies(headers)) {
            analysis.flags.push_back("HEADER_INCONSISTENCY");
            analysis.scores["header_inconsistency"] = 25;
        }

        double latency = timingAnalyzer->measureLatency(ip);
        if (latency > SUSPICIOUS_LATENCY_THRESHOLD || latency < 0) {
            analysis.flags.push_back("SUSPICIOUS_LATENCY");
            analysis.scores["latency"] = 20;
        }
        
        if (timingAnalyzer->detectVPNLatencyPattern(ip)) {
            analysis.flags.push_back("VPN_TIMING_PATTERN");
            analysis.scores["timing_pattern"] = timingAnalyzer->calculateTimingScore(ip);
        }
        
        portScanner->logPortAccess(ip, 80);
        portScanner->logPortAccess(ip, 443);
        
        if (portScanner->isPortScanPattern(ip)) {
            analysis.flags.push_back("PORT_SCAN_DETECTED");
            analysis.scores["port_scan"] = portScanner->calculateScanScore(ip);
        }

        std::vector<std::string> dnsResults = netAnalyzer->checkDNSReverse(ip);
        for (const auto& result : dnsResults) {
            if (result == "SUSPICIOUS_HOSTNAME") {
                analysis.flags.push_back("SUSPICIOUS_DNS");
                analysis.scores["dns"] = 30;
            }
        }

        std::vector<std::string> threats = repChecker->checkThreatIntel(ip);
        for (const auto& threat : threats) {
            analysis.flags.push_back(threat);
            analysis.scores["threat_" + threat] = 40;
        }

        MachineLearningDetector::Feature mlFeatures;
        mlFeatures.latency = latency;
        mlFeatures.asnType = static_cast<int>(ipType);
        mlFeatures.headerScore = headerScore;
        mlFeatures.blacklisted = !threats.empty();
        mlFeatures.geoInconsistency = 0;

        auto now = std::chrono::system_clock::now();
        auto time_t = std::chrono::system_clock::to_time_t(now);
        struct tm* timeinfo = localtime(&time_t);
        mlFeatures.timeOfDay = timeinfo->tm_hour;
        mlFeatures.requestRate = 10;

        double mlPrediction = mlDetector->predict(mlFeatures);
        analysis.confidence = mlPrediction * 100;

        if (mlPrediction > 0.7) {
            analysis.flags.push_back("ML_HIGH_CONFIDENCE_VPN");
            analysis.scores["ml_detection"] = mlPrediction * 50;
        }

        int totalScore = analysis.getTotalScore();

        if (totalScore >= 80) {
            analysis.risk = RiskLevel::CRITICAL;
        } else if (totalScore >= 60) {
            analysis.risk = RiskLevel::HIGH;
        } else if (totalScore >= 40) {
            analysis.risk = RiskLevel::MEDIUM;
        } else if (totalScore >= 20) {
            analysis.risk = RiskLevel::LOW;
        } else {
            analysis.risk = RiskLevel::SAFE;
        }

        dbManager->cacheIPAnalysis(analysis);
        dbManager->recordSession(generateSessionId(), analysis, fingerprint);

        return analysis;
    }

    std::string generateSessionId() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 15);

        const char* hex = "0123456789abcdef";
        std::string sessionId;

        for (int i = 0; i < 32; ++i) {
            sessionId += hex[dis(gen)];
        }

        return sessionId;
    }

    bool shouldBlock(const IPAnalysis& analysis) {
        return analysis.risk >= RiskLevel::HIGH ||
               analysis.type == IPType::VPN ||
               analysis.type == IPType::PROXY ||
               analysis.type == IPType::TOR;
    }
};

class HTTPResponseGenerator {
private:
    std::string generateCSS() {
        return R"(
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
            }
            .container {
                max-width: 600px;
                padding: 3rem;
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                border-radius: 20px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                border: 1px solid rgba(255,255,255,0.2);
                animation: slideIn 0.5s ease-out;
            }
            @keyframes slideIn {
                from { opacity: 0; transform: translateY(-30px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .icon {
                width: 80px;
                height: 80px;
                margin: 0 auto 1.5rem;
                background: linear-gradient(135deg, #ff6b6b, #ff4757);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 10px 30px rgba(255,107,107,0.3);
            }
            .icon::before {
                content: '⚠';
                font-size: 3rem;
            }
            h1 {
                font-size: 2.5rem;
                margin-bottom: 1rem;
                text-align: center;
                text-shadow: 0 2px 10px rgba(0,0,0,0.2);
            }
            .details {
                background: rgba(0,0,0,0.2);
                border-radius: 10px;
                padding: 1.5rem;
                margin: 2rem 0;
            }
            .detail-row {
                display: flex;
                justify-content: space-between;
                padding: 0.75rem 0;
                border-bottom: 1px solid rgba(255,255,255,0.1);
            }
            .detail-row:last-child { border-bottom: none; }
            .detail-label {
                font-weight: 600;
                opacity: 0.9;
            }
            .detail-value {
                text-align: right;
                font-family: 'Courier New', monospace;
            }
            .risk-badge {
                display: inline-block;
                padding: 0.25rem 0.75rem;
                border-radius: 20px;
                font-size: 0.875rem;
                font-weight: 600;
                text-transform: uppercase;
            }
            .risk-critical { background: #ff4757; }
            .risk-high { background: #ff6348; }
            .risk-medium { background: #ffa502; }
            .message {
                text-align: center;
                line-height: 1.6;
                opacity: 0.95;
                margin-top: 1.5rem;
            }
            .flags {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                margin-top: 1rem;
            }
            .flag {
                background: rgba(255,255,255,0.2);
                padding: 0.25rem 0.75rem;
                border-radius: 15px;
                font-size: 0.85rem;
            }
        )";
    }

public:
    void sendBlockedResponse(const IPAnalysis& analysis) {
        std::cout << "Status: 403 Forbidden\r\n";
        std::cout << "Content-Type: text/html; charset=utf-8\r\n";
        std::cout << "X-Frame-Options: DENY\r\n";
        std::cout << "X-Content-Type-Options: nosniff\r\n";
        std::cout << "Cache-Control: no-cache, no-store, must-revalidate\r\n\r\n";

        std::cout << "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n";
        std::cout << "<meta charset=\"UTF-8\">\n";
        std::cout << "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n";
        std::cout << "<title>Access Denied - VPN/Proxy Detected</title>\n";
        std::cout << "<style>" << generateCSS() << "</style>\n";
        std::cout << "</head>\n<body>\n";

        std::cout << "<div class=\"container\">\n";
        std::cout << "<div class=\"icon\"></div>\n";
        std::cout << "<h1>VPN/Proxy Detected</h1>\n";

        std::cout << "<div class=\"details\">\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">IP Address</span>\n";
        std::cout << "<span class=\"detail-value\">" << analysis.ip << "</span>\n";
        std::cout << "</div>\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">Detection Type</span>\n";
        std::cout << "<span class=\"detail-value\">" << ipTypeToString(analysis.type) << "</span>\n";
        std::cout << "</div>\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">Risk Level</span>\n";
        std::cout << "<span class=\"detail-value\">\n";
        std::cout << "<span class=\"risk-badge risk-" << riskLevelToClass(analysis.risk) << "\">";
        std::cout << riskLevelToString(analysis.risk) << "</span>\n";
        std::cout << "</span>\n</div>\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">Location</span>\n";
        std::cout << "<span class=\"detail-value\">" 
                  << analysis.location.city << ", " << analysis.location.country << "</span>\n";
        std::cout << "</div>\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">ISP/Organization</span>\n";
        std::cout << "<span class=\"detail-value\">" << analysis.location.isp << "</span>\n";
        std::cout << "</div>\n";

        std::cout << "<div class=\"detail-row\">\n";
        std::cout << "<span class=\"detail-label\">Confidence</span>\n";
        std::cout << "<span class=\"detail-value\">" 
                  << std::fixed << std::setprecision(1) << analysis.confidence << "%</span>\n";
        std::cout << "</div>\n";

        std::cout << "</div>\n";

        if (!analysis.flags.empty()) {
            std::cout << "<div class=\"flags\">\n";
            for (const auto& flag : analysis.flags) {
                std::cout << "<span class=\"flag\">" << flag << "</span>\n";
            }
            std::cout << "</div>\n";
        }

        std::cout << "<p class=\"message\">\n";
        std::cout << "Your connection has been identified as originating from a VPN, proxy, or anonymization service. ";
        std::cout << "For security reasons, access to this resource is restricted. ";
        std::cout << "Please disable your VPN/proxy and try again.\n";
        std::cout << "</p>\n";

        std::cout << "</div>\n</body>\n</html>\n";
    }

    void sendAllowedResponse() {
        std::cout << "Status: 200 OK\r\n";
        std::cout << "Content-Type: text/html; charset=utf-8\r\n";
        std::cout << "Cache-Control: no-cache\r\n\r\n";

        std::cout << "<!DOCTYPE html>\n<html>\n<head>\n";
        std::cout << "<title>Access Granted</title>\n</head>\n";
        std::cout << "<body>\n<h1>Access Granted</h1>\n";
        std::cout << "<p>Your connection has been verified.</p>\n";
        std::cout << "</body>\n</html>\n";
    }

    void sendErrorResponse(const std::string& error) {
        std::cout << "Status: 500 Internal Server Error\r\n";
        std::cout << "Content-Type: text/html; charset=utf-8\r\n\r\n";

        std::cout << "<!DOCTYPE html>\n<html>\n<head>\n";
        std::cout << "<title>Error</title>\n</head>\n";
        std::cout << "<body>\n<h1>Internal Error</h1>\n";
        std::cout << "<p>" << error << "</p>\n";
        std::cout << "</body>\n</html>\n";
    }

private:
    std::string ipTypeToString(IPType type) {
        switch(type) {
            case IPType::VPN: return "VPN";
            case IPType::PROXY: return "Proxy";
            case IPType::TOR: return "Tor Exit Node";
            case IPType::DATACENTER: return "Datacenter";
            case IPType::HOSTING: return "Hosting Provider";
            case IPType::RESIDENTIAL: return "Residential";
            case IPType::EDUCATION: return "Education";
            case IPType::GOVERNMENT: return "Government";
            default: return "Unknown";
        }
    }

    std::string riskLevelToString(RiskLevel risk) {
        switch(risk) {
            case RiskLevel::CRITICAL: return "Critical";
            case RiskLevel::HIGH: return "High";
            case RiskLevel::MEDIUM: return "Medium";
            case RiskLevel::LOW: return "Low";
            case RiskLevel::SAFE: return "Safe";
            default: return "Unknown";
        }
    }

    std::string riskLevelToClass(RiskLevel risk) {
        switch(risk) {
            case RiskLevel::CRITICAL: return "critical";
            case RiskLevel::HIGH: return "high";
            case RiskLevel::MEDIUM: return "medium";
            default: return "medium";
        }
    }
};

std::string extractClientIP(int argc, char** argv) {
    if (argc >= 2) {
        return std::string(argv[1]);
    }

    const char* envVars[] = {
        "HTTP_CF_CONNECTING_IP",
        "HTTP_X_FORWARDED_FOR",
        "HTTP_X_REAL_IP",
        "HTTP_CLIENT_IP",
        "REMOTE_ADDR"
    };

    for (const char* var : envVars) {
        const char* value = std::getenv(var);
        if (value && strlen(value) > 0) {
            std::string ip(value);

            size_t pos = ip.find(',');
            if (pos != std::string::npos) {
                ip = ip.substr(0, pos);
            }

            pos = ip.find_last_not_of(" \t\r\n");
            if (pos != std::string::npos) {
                ip = ip.substr(0, pos + 1);
            }

            pos = ip.find_first_not_of(" \t\r\n");
            if (pos != std::string::npos) {
                ip = ip.substr(pos);
            }

            return ip;
        }
    }

    return "";
}

std::map<std::string, std::string> extractHTTPHeaders() {
    std::map<std::string, std::string> headers;

    for (char** env = ::environ; *env != nullptr; ++env) {
        std::string envStr(*env);
        if (envStr.find("HTTP_") == 0) {
            size_t pos = envStr.find('=');
            if (pos != std::string::npos) {
                std::string key = envStr.substr(5, pos - 5);
                std::string value = envStr.substr(pos + 1);

                std::replace(key.begin(), key.end(), '_', '-');
                headers[key] = value;
            }
        }
    }

    return headers;
}

SessionFingerprint extractFingerprint() {
    SessionFingerprint fingerprint;

    const char* userAgent = std::getenv("HTTP_USER_AGENT");
    if (userAgent) fingerprint.userAgent = userAgent;

    const char* acceptLang = std::getenv("HTTP_ACCEPT_LANGUAGE");
    if (acceptLang) fingerprint.acceptLanguage = acceptLang;

    const char* acceptEnc = std::getenv("HTTP_ACCEPT_ENCODING");
    if (acceptEnc) fingerprint.acceptEncoding = acceptEnc;

    return fingerprint;
}

}

int main(int argc, char** argv) {
    using namespace VPNDetector;

    try {
        curl_global_init(CURL_GLOBAL_DEFAULT);

        std::string clientIP = extractClientIP(argc, argv);

        if (clientIP.empty()) {
            HTTPResponseGenerator respGen;
            respGen.sendErrorResponse("Unable to determine client IP address");
            return 1;
        }

        std::map<std::string, std::string> headers = extractHTTPHeaders();
        SessionFingerprint fingerprint = extractFingerprint();

        VPNDetectorEngine engine;
        IPAnalysis analysis = engine.analyzeIP(clientIP, headers, fingerprint);

        HTTPResponseGenerator respGen;

        if (engine.shouldBlock(analysis)) {
            std::cerr << "[VPNDetector] Blocked IP: " << clientIP 
                     << " Type: " << static_cast<int>(analysis.type)
                     << " Risk: " << static_cast<int>(analysis.risk) << std::endl;
            respGen.sendBlockedResponse(analysis);
        } else {
            std::cerr << "[VPNDetector] Allowed IP: " << clientIP << std::endl;
            respGen.sendAllowedResponse();
        }

        curl_global_cleanup();

    } catch (const std::exception& e) {
        std::cerr << "[VPNDetector] Fatal error: " << e.what() << std::endl;
        HTTPResponseGenerator respGen;
        respGen.sendErrorResponse("System error occurred");
        return 1;
    }

    return 0;
}