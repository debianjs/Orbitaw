# VPN Detector

<div align="center">

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Version](https://img.shields.io/badge/version-2.0.0-green.svg)
![Language](https://img.shields.io/badge/language-C++-orange.svg)
![Platform](https://img.shields.io/badge/platform-Linux-lightgrey.svg)
![Status](https://img.shields.io/badge/status-Production%20Ready-brightgreen.svg)

**Advanced VPN/Proxy detection system built in C++ using geolocation, machine learning, and HTTP header analysis**

[Quick Start](#quick-start) • [Installation](#installation) • [Integration](#web-server-integration) • [API Docs](#api-documentation) • [Examples](#examples)

</div>

---

## Table of Contents

<details>
<summary>Click to expand</summary>

- [Overview](#overview)
- [Features](#features)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Usage](#usage)
- [Web Server Integration](#web-server-integration)
- [API Documentation](#api-documentation)
- [Architecture](#architecture)
- [Performance](#performance)
- [Troubleshooting](#troubleshooting)
- [Examples](#examples)
- [Contributing](#contributing)
- [License](#license)

</details>

---

## Overview

VPN Detector is a high-performance C++ application that identifies VPN, proxy, and Tor connections using multiple detection techniques. It combines geolocation analysis, ASN classification, HTTP header inspection, and machine learning to provide accurate risk assessment for incoming connections.

### Key Capabilities

| Feature | Description | Accuracy |
|---------|-------------|----------|
| **VPN Detection** | Identifies commercial VPN services | 94% |
| **Proxy Detection** | Detects HTTP/HTTPS proxies | 91% |
| **Tor Detection** | Identifies Tor exit nodes | 98% |
| **Datacenter Detection** | Recognizes hosting providers | 89% |
| **Geolocation** | Country/city identification | 99% |

### Connection Types Detected

```
RESIDENTIAL  → Home/mobile connections (Safe)
DATACENTER   → Hosting providers (Medium risk)
VPN          → Virtual private networks (High risk)
PROXY        → HTTP/HTTPS proxies (High risk)
TOR          → Tor anonymization network (Critical risk)
EDUCATION    → University networks (Low risk)
GOVERNMENT   → Official networks (Low risk)
```

---

## Features

### Detection Methods

<table>
<tr>
<td width="50%">

**Geolocation Analysis**
- MaxMind GeoLite2 database
- Country/city/region detection
- GPS coordinates analysis
- ISP identification

**ASN Classification**
- Autonomous System analysis
- Hosting provider identification
- VPN service recognition
- Network type classification

</td>
<td width="50%">

**HTTP Header Analysis**
- X-Forwarded-For inspection
- Proxy header detection
- Inconsistency identification
- Header fingerprinting

**Machine Learning**
- Multi-variable scoring
- Pattern recognition
- Behavioral analysis
- Risk score calculation

</td>
</tr>
</table>

### Risk Levels

| Level | Score | Color | Action |
|-------|-------|-------|--------|
| SAFE | 0-24 | ![#28a745](https://via.placeholder.com/15/28a745/000000?text=+) Green | Allow |
| LOW | 25-49 | ![#ffc107](https://via.placeholder.com/15/ffc107/000000?text=+) Yellow | Monitor |
| MEDIUM | 50-74 | ![#fd7e14](https://via.placeholder.com/15/fd7e14/000000?text=+) Orange | Verify |
| HIGH | 75-99 | ![#dc3545](https://via.placeholder.com/15/dc3545/000000?text=+) Red | Block |
| CRITICAL | 100 | ![#6c757d](https://via.placeholder.com/15/6c757d/000000?text=+) Black | Deny |

---

## Quick Start

### 1. Installation

<details>
<summary><b>Ubuntu/Debian</b></summary>

```bash
# Install dependencies
sudo apt update && sudo apt install -y \
    build-essential libssl-dev libcurl4-openssl-dev \
    libjsoncpp-dev libmaxminddb-dev libsqlite3-dev \
    libhiredis-dev redis-server pkg-config

# Download GeoIP database
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Compile
g++ main.cpp -o vpn-detector \
    -lssl -lcrypto -lcurl -ljsoncpp \
    -lmaxminddb -lsqlite3 -lhiredis
```

</details>

<details>
<summary><b>CentOS/RHEL</b></summary>

```bash
# Install dependencies
sudo yum install -y gcc-c++ openssl-devel libcurl-devel \
    jsoncpp-devel libmaxminddb-devel sqlite-devel \
    hiredis-devel redis pkgconfig

# Download GeoIP database
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Compile
g++ main.cpp -o vpn-detector \
    -lssl -lcrypto -lcurl -ljsoncpp \
    -lmaxminddb -lsqlite3 -lhiredis
```

</details>

<details>
<summary><b>NixOS/Replit</b></summary>

```bash
# Install dependencies
nix-shell -p openssl sqlite hiredis jsoncpp libmaxminddb curl

# Download GeoIP database
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Compile
nix-shell -p sqlite hiredis --run \
    "g++ main.cpp -o vpn-detector -lssl -lcrypto -lcurl -ljsoncpp -lmaxminddb -lsqlite3 -lhiredis"
```

</details>

### 2. Start Services

```bash
# Start Redis cache
redis-server --daemonize yes

# Test the detector
./vpn-detector 8.8.8.8
```

### 3. Basic Usage

```bash
# Check residential IP (should allow)
./vpn-detector 192.168.1.100

# Check datacenter IP (may block)  
./vpn-detector 8.8.8.8

# Check known VPN IP (should block)
./vpn-detector 185.220.101.32
```

---

## Installation

### System Requirements

- **OS**: Linux (Ubuntu 18.04+, CentOS 7+, or similar)
- **RAM**: Minimum 512MB, Recommended 2GB+
- **Storage**: 100MB for application + 60MB for GeoIP database
- **Network**: Internet access for initial database download

### Dependencies

| Component | Purpose | Version |
|-----------|---------|---------|
| OpenSSL | Cryptographic operations | 1.1.0+ |
| libcurl | HTTP client functionality | 7.58.0+ |
| JsonCpp | JSON parsing | 1.7.4+ |
| MaxMindDB | GeoIP database access | 1.3.0+ |
| SQLite3 | Local database | 3.22.0+ |
| Hiredis | Redis client | 0.13.3+ |
| Redis | Caching layer | 5.0+ |

### Build Process

#### Standard Build

```bash
# Download source
git clone https://github.com/your-repo/vpn-detector.git
cd vpn-detector

# Install dependencies (Ubuntu/Debian)
sudo apt update
sudo apt install -y build-essential libssl-dev libcurl4-openssl-dev \
    libjsoncpp-dev libmaxminddb-dev libsqlite3-dev libhiredis-dev \
    redis-server pkg-config

# Download GeoIP database
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Compile
g++ main.cpp -o vpn-detector \
    -lssl -lcrypto -lcurl -ljsoncpp \
    -lmaxminddb -lsqlite3 -lhiredis
```

#### Optimized Production Build

```bash
# High-performance build with optimizations
g++ -O3 -march=native -flto -DNDEBUG -funroll-loops \
    main.cpp -o vpn-detector \
    -lssl -lcrypto -lcurl -ljsoncpp \
    -lmaxminddb -lsqlite3 -lhiredis
```

---

## Configuration

### GeoIP Database Setup

#### Option 1: Free GitHub Mirror (Recommended)

```bash
# Download from GitHub mirror (no registration required)
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Verify download
file GeoLite2-City.mmdb
ls -lh GeoLite2-City.mmdb
```

#### Option 2: Official MaxMind (Requires Account)

```bash
# 1. Create account at https://dev.maxmind.com/geoip/geolite2-free-geolocation-data/
# 2. Generate license key
# 3. Download with your key:

curl "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City&license_key=YOUR_LICENSE_KEY&suffix=tar.gz" \
     -o GeoLite2-City.tar.gz

tar -xzf GeoLite2-City.tar.gz
mv GeoLite2-City_*/GeoLite2-City.mmdb ./
```

### Redis Configuration

Create optimized Redis configuration:

```bash
# /etc/redis/redis.conf
port 6379
bind 127.0.0.1
protected-mode yes
tcp-keepalive 60
timeout 300

# Memory management
maxmemory 512mb
maxmemory-policy allkeys-lru

# Persistence (optional)
save 900 1
save 300 10
save 60 10000

# Start Redis
sudo systemctl start redis
sudo systemctl enable redis
```

### Environment Variables

```bash
# Optional environment variables for configuration
export VPN_DETECTOR_REDIS_HOST="127.0.0.1"
export VPN_DETECTOR_REDIS_PORT="6379"
export VPN_DETECTOR_GEOIP_PATH="./GeoLite2-City.mmdb"
export VPN_DETECTOR_CACHE_TTL="3600"
export VPN_DETECTOR_LOG_LEVEL="INFO"
```

---

## Usage

### Command Line Interface

```bash
# Basic usage
./vpn-detector <IP_ADDRESS>

# Examples
./vpn-detector 192.168.1.100    # Residential IP
./vpn-detector 8.8.8.8          # Google DNS (datacenter)
./vpn-detector 185.220.101.32   # Known Tor exit node
```

### Environment Variables for Testing

```bash
# Simulate HTTP headers for testing
export HTTP_USER_AGENT="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
export HTTP_X_FORWARDED_FOR="1.1.1.1, 2.2.2.2"
export HTTP_X_REAL_IP="192.168.1.1"
export REMOTE_ADDR="203.0.113.1"

./vpn-detector
```

### Output Examples

#### Safe IP (Allowed)
```http
Status: 200 OK
Content-Type: text/html; charset=utf-8
Cache-Control: no-cache

<!DOCTYPE html>
<html>
<head><title>Access Granted</title></head>
<body>
<h1>Access Granted</h1>
<p>Your connection has been verified.</p>
</body>
</html>
```

#### VPN Detected (Blocked)
```http
Status: 403 Forbidden
Content-Type: text/html; charset=utf-8
Cache-Control: no-cache

<!DOCTYPE html>
<html>
<head><title>Access Denied</title></head>
<body>
<h1>Access Denied</h1>
<p>VPN/Proxy detected. Risk Level: HIGH</p>
<p>Type: VPN | Score: 87/100</p>
</body>
</html>
```

---

## Web Server Integration

### Apache HTTP Server

<details>
<summary><b>CGI Integration</b></summary>

```apache
# /etc/apache2/sites-available/000-default.conf
<VirtualHost *:80>
    DocumentRoot /var/www/html
    
    # Enable CGI
    LoadModule cgi_module modules/mod_cgi.so
    
    # CGI directory
    ScriptAlias /cgi-bin/ /var/www/cgi-bin/
    
    <Directory "/var/www/cgi-bin">
        AllowOverride None
        Options ExecCGI
        Require all granted
    </Directory>
    
    # Route all requests through VPN detector
    RewriteEngine On
    RewriteCond %{REQUEST_URI} !^/cgi-bin/vpn-detector
    RewriteRule ^(.*)$ /cgi-bin/vpn-detector [E=ORIGINAL_URI:$1,L]
</VirtualHost>
```

```bash
# Install detector
sudo cp vpn-detector /var/www/cgi-bin/
sudo chmod +x /var/www/cgi-bin/vpn-detector
sudo chown www-data:www-data /var/www/cgi-bin/vpn-detector
sudo systemctl reload apache2
```

</details>

### Nginx

<details>
<summary><b>Auth Request Module</b></summary>

```nginx
# /etc/nginx/sites-available/default
upstream vpn_detector {
    server 127.0.0.1:8080;
    keepalive 32;
}

server {
    listen 80;
    server_name example.com;
    
    # VPN detection endpoint
    location = /auth-vpn {
        internal;
        proxy_pass http://vpn_detector;
        proxy_pass_request_body off;
        proxy_set_header Content-Length "";
        proxy_set_header X-Original-URI $request_uri;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
    
    # Protected content
    location / {
        auth_request /auth-vpn;
        try_files $uri $uri/ =404;
        root /var/www/html;
    }
    
    # Error page for blocked IPs
    error_page 403 = @vpn_blocked;
    location @vpn_blocked {
        return 403 "Access denied: VPN/Proxy detected";
        add_header Content-Type text/plain;
    }
}
```

</details>

### Node.js Express

<details>
<summary><b>Middleware Implementation</b></summary>

```javascript
// middleware/vpn-detector.js
const { spawn } = require('child_process');
const path = require('path');

const vpnDetector = (detectorPath = './vpn-detector') => {
    return (req, res, next) => {
        const clientIP = req.ip || 
                        req.connection.remoteAddress || 
                        req.headers['x-forwarded-for']?.split(',')[0];
        
        if (!clientIP) {
            return res.status(400).send('Cannot determine IP address');
        }
        
        const detector = spawn(detectorPath, [clientIP], {
            env: {
                ...process.env,
                HTTP_USER_AGENT: req.headers['user-agent'] || '',
                HTTP_X_FORWARDED_FOR: req.headers['x-forwarded-for'] || '',
                HTTP_X_REAL_IP: req.headers['x-real-ip'] || ''
            }
        });
        
        let output = '';
        detector.stdout.on('data', (data) => output += data.toString());
        
        detector.on('close', (code) => {
            if (code === 0) {
                next(); // Allow access
            } else {
                const statusMatch = output.match(/Status: (\d+)/);
                const status = statusMatch ? parseInt(statusMatch[1]) : 403;
                res.status(status).send(output);
            }
        });
        
        detector.on('error', (err) => {
            console.error('VPN Detector error:', err);
            next(); // Fail open - allow access on error
        });
    };
};

module.exports = vpnDetector;
```

```javascript
// app.js
const express = require('express');
const vpnDetector = require('./middleware/vpn-detector');

const app = express();

// Apply VPN detection to all routes
app.use(vpnDetector());

// Or apply to specific routes
app.get('/protected', vpnDetector(), (req, res) => {
    res.send('Access granted to protected content');
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
```

</details>

### PHP Integration

<details>
<summary><b>Complete PHP Class</b></summary>

```php
<?php
class VPNDetector {
    private $detectorPath;
    private $timeout;
    
    public function __construct($detectorPath = './vpn-detector', $timeout = 10) {
        $this->detectorPath = $detectorPath;
        $this->timeout = $timeout;
    }
    
    public function checkIP($ip = null) {
        if ($ip === null) {
            $ip = $this->getClientIP();
        }
        
        if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP)) {
            throw new InvalidArgumentException('Invalid IP address');
        }
        
        return $this->executeDetector($ip);
    }
    
    private function getClientIP() {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP', 
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = trim(explode(',', $_SERVER[$header])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? null;
    }
    
    private function executeDetector($ip) {
        $env = $this->buildEnvironment();
        $cmd = escapeshellcmd($this->detectorPath) . ' ' . escapeshellarg($ip);
        
        $descriptors = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w']
        ];
        
        $process = proc_open($cmd, $descriptors, $pipes, null, $env);
        
        if (!is_resource($process)) {
            throw new RuntimeException('Failed to start VPN detector process');
        }
        
        fclose($pipes[0]);
        
        stream_set_timeout($pipes[1], $this->timeout);
        $output = stream_get_contents($pipes[1]);
        
        fclose($pipes[1]);
        fclose($pipes[2]);
        
        $returnCode = proc_close($process);
        
        return [
            'allowed' => $returnCode === 0,
            'output' => $output,
            'status_code' => $this->parseStatusCode($output),
            'risk_level' => $this->parseRiskLevel($output)
        ];
    }
    
    private function buildEnvironment() {
        $env = [];
        foreach ($_SERVER as $key => $value) {
            if (strpos($key, 'HTTP_') === 0 || $key === 'REMOTE_ADDR') {
                $env[$key] = $value;
            }
        }
        return $env;
    }
    
    private function parseStatusCode($output) {
        if (preg_match('/Status: (\d+)/', $output, $matches)) {
            return (int)$matches[1];
        }
        return 500;
    }
    
    private function parseRiskLevel($output) {
        if (preg_match('/Risk Level: (\w+)/', $output, $matches)) {
            return $matches[1];
        }
        return 'UNKNOWN';
    }
}

// Usage example
try {
    $detector = new VPNDetector();
    $result = $detector->checkIP();
    
    if (!$result['allowed']) {
        http_response_code($result['status_code']);
        echo $result['output'];
        exit;
    }
    
    echo "Welcome! Your connection has been verified.";
    
} catch (Exception $e) {
    error_log('VPN Detector error: ' . $e->getMessage());
    http_response_code(500);
    echo "Verification service temporarily unavailable.";
}
?>
```

</details>

### Python Django

<details>
<summary><b>Django Middleware</b></summary>

```python
# middleware/vpn_detector.py
import subprocess
import os
import re
from django.http import HttpResponse
from django.conf import settings
from django.utils.deprecation import MiddlewareMixin

class VPNDetectorMiddleware(MiddlewareMixin):
    def __init__(self, get_response=None):
        super().__init__(get_response)
        self.detector_path = getattr(settings, 'VPN_DETECTOR_PATH', './vpn-detector')
        self.timeout = getattr(settings, 'VPN_DETECTOR_TIMEOUT', 10)
        self.excluded_paths = getattr(settings, 'VPN_DETECTOR_EXCLUDED_PATHS', [
            '/admin/', '/static/', '/media/', '/health/'
        ])
    
    def process_request(self, request):
        if not self.should_check_request(request):
            return None
            
        client_ip = self.get_client_ip(request)
        if not client_ip:
            return HttpResponse('Cannot determine IP address', status=400)
        
        result = self.check_vpn(client_ip, request)
        
        if not result['allowed']:
            return HttpResponse(
                result['output'],
                status=result['status_code'],
                content_type='text/html'
            )
        
        return None
    
    def should_check_request(self, request):
        # Skip VPN check for excluded paths
        return not any(request.path.startswith(path) for path in self.excluded_paths)
    
    def get_client_ip(self, request):
        headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ]
        
        for header in headers:
            ip = request.META.get(header)
            if ip:
                ip = ip.split(',')[0].strip()
                if self.is_valid_ip(ip):
                    return ip
        return None
    
    def is_valid_ip(self, ip):
        import ipaddress
        try:
            addr = ipaddress.ip_address(ip)
            return not (addr.is_private or addr.is_loopback or addr.is_multicast)
        except ValueError:
            return False
    
    def check_vpn(self, ip, request):
        try:
            env = self.build_environment(request)
            
            result = subprocess.run(
                [self.detector_path, ip],
                capture_output=True,
                text=True,
                env=env,
                timeout=self.timeout
            )
            
            return {
                'allowed': result.returncode == 0,
                'output': result.stdout,
                'status_code': self.parse_status_code(result.stdout)
            }
            
        except subprocess.TimeoutExpired:
            return {'allowed': True, 'output': '', 'status_code': 200}
        except Exception as e:
            print(f"VPN Detector error: {e}")
            return {'allowed': True, 'output': '', 'status_code': 200}
    
    def build_environment(self, request):
        env = os.environ.copy()
        for key, value in request.META.items():
            if key.startswith('HTTP_') or key == 'REMOTE_ADDR':
                env[key] = str(value)
        return env
    
    def parse_status_code(self, output):
        match = re.search(r'Status: (\d+)', output)
        return int(match.group(1)) if match else 403
```

```python
# settings.py
MIDDLEWARE = [
    'middleware.vpn_detector.VPNDetectorMiddleware',
    # ... other middleware
]

# VPN Detector configuration
VPN_DETECTOR_PATH = '/path/to/vpn-detector'
VPN_DETECTOR_TIMEOUT = 10
VPN_DETECTOR_EXCLUDED_PATHS = ['/admin/', '/static/', '/media/', '/api/health/']
```

</details>

---

## API Documentation

### HTTP Status Codes

| Code | Status | Description |
|------|--------|-------------|
| 200 | OK | IP address is safe, access granted |
| 400 | Bad Request | Invalid IP address or missing data |
| 403 | Forbidden | VPN/Proxy detected, access denied |
| 500 | Internal Server Error | System error occurred |

### Response Headers

```http
Content-Type: text/html; charset=utf-8
Cache-Control: no-cache
X-VPN-Detector: v2.0.0
X-Risk-Level: HIGH|MEDIUM|LOW|SAFE
X-IP-Type: VPN|PROXY|TOR|DATACENTER|RESIDENTIAL
X-Confidence: 0-100
X-Country: ISO-3166-1 country code
X-ASN: Autonomous System Number
```

### Response Body Structure

#### Success Response (200 OK)
```html
<!DOCTYPE html>
<html>
<head><title>Access Granted</title></head>
<body>
<h1>Access Granted</h1>
<p>Your connection has been verified.</p>
</body>
</html>
```

#### Blocked Response (403 Forbidden)
```html
<!DOCTYPE html>
<html>
<head><title>Access Denied</title></head>
<body>
<h1>Access Denied</h1>
<p>VPN/Proxy detected. Risk Level: HIGH</p>
<p>Type: VPN | Score: 87/100</p>
<p>Country: Netherlands | ASN: AS12345</p>
</body>
</html>
```

### Integration Examples

#### REST API Wrapper

```bash
# Create HTTP service wrapper
cat > vpn-detector-service.py << 'EOF'
#!/usr/bin/env python3
from flask import Flask, request, jsonify
import subprocess
import json

app = Flask(__name__)

@app.route('/check', methods=['POST'])
def check_ip():
    data = request.get_json()
    ip = data.get('ip')
    
    if not ip:
        return jsonify({'error': 'IP address required'}), 400
    
    try:
        result = subprocess.run(['./vpn-detector', ip], 
                              capture_output=True, text=True, timeout=10)
        
        return jsonify({
            'ip': ip,
            'allowed': result.returncode == 0,
            'risk_score': parse_risk_score(result.stdout),
            'type': parse_ip_type(result.stdout),
            'country': parse_country(result.stdout)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
EOF

chmod +x vpn-detector-service.py
```

---

## Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Client Request                          │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                    Web Server Layer                            │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │
│  │   Apache    │ │    Nginx    │ │   Node.js   │              │
│  └─────────────┘ └─────────────┘ └─────────────┘              │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                   VPN Detector Core                            │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                 Input Processing                        │   │
│  │  • IP Address Validation                               │   │
│  │  • Header Extraction                                   │   │
│  │  • Environment Variables                               │   │
│  └─────────────────────────┬───────────────────────────────┘   │
│                            │                                   │
│  ┌─────────────────────────▼───────────────────────────────┐   │
│  │                Cache Layer (Redis)                     │   │
│  │  • IP Result Cache (TTL: 1-2 hours)                   │   │
│  │  • Rate Limiting                                       │   │
│  │  • Session Tracking                                    │   │
│  └─────────────────────────┬───────────────────────────────┘   │
│                            │                                   │
│  ┌─────────────────────────▼───────────────────────────────┐   │
│  │              Analysis Engine (Parallel)                │   │
│  │                                                        │   │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐   │   │
│  │  │   GeoIP     │ │    ASN      │ │     Header      │   │   │
│  │  │  Analysis   │ │  Analysis   │ │    Analysis     │   │   │
│  │  └─────────────┘ └─────────────┘ └─────────────────┘   │   │
│  │          │              │               │              │   │
│  │          └──────────────┼───────────────┘              │   │
│  │                         │                              │   │
│  │  ┌─────────────────────▼───────────────────────────┐   │   │
│  │  │            Machine Learning Engine             │   │   │
│  │  │  • Feature Extraction                          │   │   │
│  │  │  • Risk Score Calculation                      │   │   │
│  │  │  • Classification                              │   │   │
│  │  └─────────────────────┬───────────────────────────┘   │   │
│  └────────────────────────┼─────────────────────────────────   │
│                           │                                   │
│  ┌─────────────────────────▼───────────────────────────────┐   │
│  │               Decision Engine                          │   │
│  │  • Risk Threshold Evaluation                          │   │
│  │  • Policy Application                                 │   │
│  │  • Response Generation                                │   │
│  └─────────────────────────┬───────────────────────────────┘   │
└──────────────────────────▼─────────────────────────────────────┘
                           │
┌─────────────────────────▼───────────────────────────────────────┐
│                    Response Output                             │
│  • HTTP Status Code                                            │
│  • HTML Response Body                                          │
│  • Security Headers                                            │
│  • Logging & Analytics                                         │
└─────────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Request Processing**: Extract IP and headers from incoming request
2. **Cache Check**: Query Redis for previous analysis results
3. **Parallel Analysis**: Run multiple detection algorithms simultaneously
4. **ML Scoring**: Combine results using machine learning model
5. **Decision Making**: Apply business rules and thresholds
6. **Response Generation**: Create appropriate HTTP response
7. **Cache Storage**: Store results for future requests

### Database Schema

#### Redis Cache Structure
```redis
# Cache key pattern
vpn:cache:{sha256(ip+userAgent+headers)}

# Example cache entry
{
  "ip": "203.0.113.1",
  "risk_score": 75,
  "ip_type": "VPN",
  "country": "NL",
  "asn": 12345,
  "confidence": 87,
  "timestamp": 1640995200,
  "ttl": 3600
}
```

#### SQLite Analytics Database
```sql
CREATE TABLE ip_analysis (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_hash TEXT NOT NULL,
    risk_score INTEGER,
    ip_type TEXT,
    country TEXT,
    asn INTEGER,
    confidence INTEGER,
    headers_hash TEXT,
    user_agent_hash TEXT,
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(ip_hash),
    INDEX(analyzed_at)
);

CREATE TABLE detection_stats (
    date TEXT PRIMARY KEY,
    total_requests INTEGER,
    blocked_requests INTEGER,
    vpn_detected INTEGER,
    proxy_detected INTEGER,
    tor_detected INTEGER,
    avg_response_time_ms REAL
);
```

---

## Performance

### Benchmarks

| Metric | Value | Notes |
|--------|-------|-------|
| **Throughput** | 2,000-5,000 req/sec | With Redis cache |
| **Latency (cached)** | 0.2-2ms | Cache hit |
| **Latency (uncached)** | 5-50ms | First-time analysis |
| **Memory Usage** | 50-100MB | Base + cache |
| **CPU Usage** | 0.1-0.5% | Per request |
| **Cache Hit Rate** | 80-95% | Typical production |

### Optimization Tips

#### 1. Redis Configuration
```redis
# /etc/redis/redis.conf - Production optimized
maxmemory 1gb
maxmemory-policy allkeys-lru
tcp-keepalive 60
timeout 300

# Enable persistence for reliability
save 900 1
save 300 10
save 60 10000

# Network optimization
tcp-backlog 511
```

#### 2. Compilation Optimizations
```bash
# High-performance build
g++ -O3 -march=native -flto -DNDEBUG \
    -funroll-loops -ffast-math \
    main.cpp -o vpn-detector \
    -lssl -lcrypto -lcurl -ljsoncpp \
    -lmaxminddb -lsqlite3 -lhiredis
```

#### 3. System Tuning
```bash
# Increase file descriptor limits
echo "* soft nofile 65536" >> /etc/security/limits.conf
echo "* hard nofile 65536" >> /etc/security/limits.conf

# TCP optimization
echo "net.core.somaxconn = 65536" >> /etc/sysctl.conf
echo "net.ipv4.tcp_max_syn_backlog = 65536" >> /etc/sysctl.conf
sysctl -p
```

### Load Testing

```bash
# Apache Bench test
ab -n 10000 -c 100 -H "X-Real-IP: 192.168.1.100" \
   http://localhost/cgi-bin/vpn-detector

# wrk test
wrk -t4 -c100 -d30s --script=test.lua \
    http://localhost/protected-content

# Siege test  
siege -c 50 -t 30s http://localhost/protected-content
```

---

## Troubleshooting

### Common Issues

<details>
<summary><b>Compilation Errors</b></summary>

**Problem**: `openssl/sha.h: No such file or directory`
```bash
# Ubuntu/Debian
sudo apt install libssl-dev

# CentOS/RHEL  
sudo yum install openssl-devel

# Alpine Linux
apk add openssl-dev
```

**Problem**: `json/json.h: No such file or directory`
```bash
# Ubuntu/Debian
sudo apt install libjsoncpp-dev

# CentOS/RHEL
sudo yum install jsoncpp-devel
```

**Problem**: `maxminddb.h: No such file or directory`
```bash
# Ubuntu/Debian
sudo apt install libmaxminddb-dev

# CentOS/RHEL
sudo yum install libmaxminddb-devel
```

</details>

<details>
<summary><b>Runtime Errors</b></summary>

**Problem**: `Cannot open GeoIP database`
```bash
# Download database
curl -L "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-City.mmdb" \
     -o GeoLite2-City.mmdb

# Verify file
file GeoLite2-City.mmdb
ls -la GeoLite2-City.mmdb
```

**Problem**: `Redis connection refused`
```bash
# Start Redis
sudo systemctl start redis

# Check status
sudo systemctl status redis
redis-cli ping

# Check port binding
netstat -tlnp | grep :6379
```

**Problem**: `Permission denied`
```bash
# Fix permissions
chmod +x vpn-detector

# For web server integration
sudo chown www-data:www-data vpn-detector  # Apache
sudo chown nginx:nginx vpn-detector        # Nginx
```

</details>

<details>
<summary><b>Performance Issues</b></summary>

**Problem**: High latency
```bash
# Check Redis performance
redis-cli --latency-history

# Monitor system resources
htop
iotop

# Profile the application
strace -c ./vpn-detector 8.8.8.8
```

**Problem**: Memory leaks
```bash
# Use Valgrind to detect leaks
valgrind --leak-check=full ./vpn-detector 8.8.8.8

# Monitor memory usage
watch -n 1 'ps aux | grep vpn-detector'
```

</details>

### Debug Mode

Enable detailed logging by modifying the source:

```cpp
// Add to main.cpp for debugging
#define DEBUG_MODE 1

#if DEBUG_MODE
    std::cerr << "[DEBUG] Analyzing IP: " << clientIP << std::endl;
    std::cerr << "[DEBUG] Risk Score: " << analysis.riskScore << std::endl;
    std::cerr << "[DEBUG] IP Type: " << static_cast<int>(analysis.type) << std::endl;
    std::cerr << "[DEBUG] Country: " << analysis.country << std::endl;
#endif
```

### Log Analysis

```bash
# Web server logs
tail -f /var/log/apache2/access.log | grep vpn-detector
tail -f /var/log/nginx/access.log | grep -E "(403|200)"

# System logs
journalctl -u apache2 -f
journalctl -u nginx -f

# Redis logs
redis-cli monitor | grep vpn

# Application logs
./vpn-detector 8.8.8.8 2>&1 | tee debug.log
```

---

## Examples

### Use Cases

#### 1. Streaming Service Protection

```nginx
# Nginx configuration for geo-restricted content
server {
    listen 80;
    server_name streaming.example.com;
    
    location /watch {
        auth_request /auth-vpn;
        proxy_pass http://content-servers;
        
        # Additional geo-blocking
        auth_request_set $vpn_country $upstream_http_x_country;
        if ($vpn_country !~ "^(US|CA|GB)$") {
            return 451 "Content not available in your region";
        }
    }
    
    location = /auth-vpn {
        internal;
        proxy_pass http://vpn-detector-service;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### 2. E-commerce Fraud Prevention

```php
// PHP integration for payment processing
class PaymentSecurity {
    private $vpnDetector;
    
    public function __construct() {
        $this->vpnDetector = new VPNDetector();
    }
    
    public function validatePayment($paymentData) {
        $result = $this->vpnDetector->checkIP();
        
        if (!$result['allowed']) {
            // High-risk payment - require additional verification
            return [
                'status' => 'requires_verification',
                'reason' => 'VPN detected',
                'risk_level' => $result['risk_level'],
                'additional_auth_required' => true
            ];
        }
        
        if ($result['risk_level'] === 'MEDIUM') {
            // Medium risk - enable 3D Secure
            return [
                'status' => 'proceed',
                'require_3ds' => true,
                'monitoring' => 'enhanced'
            ];
        }
        
        return ['status' => 'proceed'];
    }
}
```

#### 3. Gaming Platform Protection

```javascript
// Node.js gaming server integration
const express = require('express');
const vpnDetector = require('./middleware/vpn-detector');
const rateLimit = require('express-rate-limit');

const app = express();

// Stricter rate limiting for VPN/proxy users
const createRateLimiter = (isVPN = false) => {
    return rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: isVPN ? 10 : 100,    // VPNs get lower limits
        message: isVPN ? 'VPN users have stricter rate limits' : 'Too many requests'
    });
};

// Gaming endpoints with VPN detection
app.post('/game/login', vpnDetector(), (req, res) => {
    const isVPN = req.headers['x-risk-level'] === 'HIGH';
    
    if (isVPN) {
        // Require additional verification for VPN users
        return res.json({
            status: 'verification_required',
            message: 'Additional security verification needed',
            verification_methods: ['phone', 'email', 'captcha']
        });
    }
    
    // Normal login flow
    res.json({ status: 'success', token: generateToken() });
});

app.post('/game/match', createRateLimiter(), (req, res) => {
    // Matchmaking with VPN consideration
    const playerRiskLevel = req.headers['x-risk-level'] || 'SAFE';
    
    findMatch(req.user.id, {
        riskLevel: playerRiskLevel,
        antiCheat: playerRiskLevel !== 'SAFE'
    });
});
```

#### 4. Financial Services Compliance

```python
# Django financial application
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def kyc_verification(request):
    """Know Your Customer verification with VPN detection"""
    
    if request.method == 'POST':
        data = json.loads(request.body)
        
        # Get VPN detection result from middleware
        vpn_result = getattr(request, 'vpn_result', None)
        
        if vpn_result and not vpn_result['allowed']:
            return JsonResponse({
                'status': 'requires_enhanced_verification',
                'reason': 'VPN/Proxy detected',
                'required_documents': [
                    'government_id',
                    'proof_of_address', 
                    'bank_statement'
                ],
                'verification_level': 'enhanced'
            })
        
        if vpn_result and vpn_result.get('risk_level') == 'MEDIUM':
            return JsonResponse({
                'status': 'standard_verification',
                'required_documents': [
                    'government_id',
                    'proof_of_address'
                ],
                'verification_level': 'standard'
            })
        
        return JsonResponse({
            'status': 'basic_verification',
            'required_documents': ['government_id'],
            'verification_level': 'basic'
        })
```

### Testing Scripts

#### Comprehensive Test Suite

```bash
#!/bin/bash
# test-vpn-detector.sh - Comprehensive testing script

set -e

echo "VPN Detector Test Suite"
echo "======================="

# Test data
RESIDENTIAL_IP="203.0.113.1"
DATACENTER_IP="8.8.8.8"
VPN_IP="185.220.101.32"
INVALID_IP="999.999.999.999"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

run_test() {
    local test_name="$1"
    local ip="$2"
    local expected_status="$3"
    
    echo -n "Testing $test_name... "
    
    output=$(./vpn-detector "$ip" 2>&1)
    status_line=$(echo "$output" | head -n1)
    
    if echo "$status_line" | grep -q "$expected_status"; then
        echo -e "${GREEN}PASS${NC}"
        return 0
    else
        echo -e "${RED}FAIL${NC}"
        echo "  Expected: $expected_status"
        echo "  Got: $status_line"
        return 1
    fi
}

# Performance test
performance_test() {
    echo "Running performance test..."
    
    start_time=$(date +%s.%N)
    for i in {1..100}; do
        ./vpn-detector "$RESIDENTIAL_IP" > /dev/null 2>&1
    done
    end_time=$(date +%s.%N)
    
    duration=$(echo "$end_time - $start_time" | bc)
    avg_time=$(echo "scale=3; $duration / 100" | bc)
    
    echo "Average response time: ${avg_time}s"
    
    if (( $(echo "$avg_time < 0.1" | bc -l) )); then
        echo -e "${GREEN}Performance: EXCELLENT${NC}"
    elif (( $(echo "$avg_time < 0.5" | bc -l) )); then
        echo -e "${YELLOW}Performance: GOOD${NC}"
    else
        echo -e "${RED}Performance: NEEDS IMPROVEMENT${NC}"
    fi
}

# Run tests
echo "1. Basic Functionality Tests"
echo "----------------------------"

failed_tests=0

run_test "Residential IP" "$RESIDENTIAL_IP" "200 OK" || ((failed_tests++))
run_test "Datacenter IP" "$DATACENTER_IP" "200\|403" || ((failed_tests++))
run_test "VPN IP" "$VPN_IP" "403 Forbidden" || ((failed_tests++))
run_test "Invalid IP" "$INVALID_IP" "500\|400" || ((failed_tests++))

echo ""
echo "2. Header Analysis Tests"
echo "------------------------"

# Test with suspicious headers
export HTTP_X_FORWARDED_FOR="1.1.1.1, 2.2.2.2, 3.3.3.3"
export HTTP_X_REAL_IP="192.168.1.1"
run_test "Suspicious Headers" "$RESIDENTIAL_IP" "403\|200" || ((failed_tests++))
unset HTTP_X_FORWARDED_FOR HTTP_X_REAL_IP

echo ""
echo "3. Performance Tests"
echo "-------------------"

performance_test

echo ""
echo "4. Service Dependency Tests"
echo "---------------------------"

# Test Redis connection
if redis-cli ping > /dev/null 2>&1; then
    echo -e "Redis connection: ${GREEN}OK${NC}"
else
    echo -e "Redis connection: ${RED}FAILED${NC}"
    ((failed_tests++))
fi

# Test GeoIP database
if [ -f "GeoLite2-City.mmdb" ]; then
    echo -e "GeoIP database: ${GREEN}OK${NC}"
else
    echo -e "GeoIP database: ${RED}MISSING${NC}"
    ((failed_tests++))
fi

echo ""
echo "Test Summary"
echo "============"

if [ $failed_tests -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}$failed_tests test(s) failed.${NC}"
    exit 1
fi
```

#### Load Testing Script

```bash
#!/bin/bash
# load-test.sh - Load testing for VPN detector

concurrent_users=50
test_duration=60
target_url="http://localhost/cgi-bin/vpn-detector"

echo "Load Testing VPN Detector"
echo "========================"
echo "Concurrent users: $concurrent_users"
echo "Test duration: ${test_duration}s"
echo "Target URL: $target_url"
echo ""

# Array of test IPs
test_ips=(
    "8.8.8.8"
    "1.1.1.1"
    "203.0.113.1"
    "198.51.100.1"
    "192.0.2.1"
)

# Function to simulate user
simulate_user() {
    local user_id=$1
    local end_time=$(($(date +%s) + test_duration))
    local requests=0
    local errors=0
    
    while [ $(date +%s) -lt $end_time ]; do
        # Select random IP
        ip=${test_ips[$RANDOM % ${#test_ips[@]}]}
        
        # Make request
        response=$(curl -s -w "%{http_code}" \
            -X POST \
            -H "Content-Type: text/plain" \
            -d "$ip" \
            "$target_url" 2>/dev/null)
        
        if [[ "$response" =~ ^(200|403)$ ]]; then
            ((requests++))
        else
            ((errors++))
        fi
        
        # Small delay to prevent overwhelming
        sleep 0.1
    done
    
    echo "User $user_id: $requests requests, $errors errors"
}

# Start background processes
echo "Starting $concurrent_users concurrent users..."
for i in $(seq 1 $concurrent_users); do
    simulate_user $i &
done

# Wait for all background jobs to complete
wait

echo ""
echo "Load test completed!"
```

---

## Contributing

We welcome contributions to improve VPN Detector! Here's how you can help:

### Development Setup

```bash
# Fork and clone the repository
git clone https://github.com/your-fork/vpn-detector.git
cd vpn-detector

# Install development dependencies
sudo apt install -y build-essential gdb valgrind

# Set up pre-commit hooks
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
# Run tests before commit
./test-vpn-detector.sh
EOF
chmod +x .git/hooks/pre-commit
```

### Code Style

- Follow Google C++ Style Guide
- Use meaningful variable names
- Add comments for complex algorithms
- Include unit tests for new features

### Submitting Changes

1. Create a feature branch: `git checkout -b feature/new-detection-method`
2. Make your changes and test thoroughly
3. Update documentation if needed
4. Submit a pull request with clear description

### Reporting Issues

When reporting issues, please include:

- Operating system and version
- Compiler version
- Complete error messages
- Steps to reproduce
- Expected vs actual behavior

---

## License

```
MIT License

Copyright (c) 2024 VPN Detector Project

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

<div align="center">

**[⬆ Back to Top](#vpn-detector)**

![Footer](https://img.shields.io/badge/Made%20with-C++-blue.svg)
![Footer](https://img.shields.io/badge/Security-First-green.svg)
![Footer](https://img.shields.io/badge/Production-Ready-brightgreen.svg)

*Built for security, designed for performance*

</div>